# OP Printing Hub — V7

V7 hardens the payment flow and customer-facing order journey.

- Added server-side Razorpay signature verification at `/api/payment/verify`.
- Payment verification checks the stored Razorpay order reference before marking an order paid.
- Stores `payment_id` and `payment_verified_at` and creates payment-confirmed status history.
- Checkout now uses `next/script` and redirects to a payment-success page after verification.
- Added payment success page with tracking + WhatsApp follow-up.
- Fixed customer account sign-in link to `/login`.
- Added Supabase Storage policies for private customer artwork folders.
- Added `orders.payment_id` and `orders.payment_verified_at` migration-safe columns.

## Production gate

Before live payments: run the SQL migration, test Razorpay in test mode, configure webhook reconciliation/idempotency, test refunds and failed payments, verify Supabase RLS/storage policies, and confirm tax/shipping/invoice rules.
