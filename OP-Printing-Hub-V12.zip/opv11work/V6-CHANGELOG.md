# OP Printing Hub V6

This release advances the project toward a usable online printing store.

- Customer signup/sign-in with Supabase Auth
- Customer account/order area
- Auth-protected admin area
- Product management and order status management
- Artwork upload API with private storage foundation
- Server-side authoritative order pricing and persistence
- Real Razorpay order-creation adapter when credentials are configured
- Razorpay Checkout launch screen
- Webhook HMAC verification foundation
- Live public order tracking from Supabase
- Expanded RLS-oriented schema and admin role model

## Production gate
Do not take live payments until Razorpay test-mode checkout, webhook reconciliation, refunds, duplicate webhook handling, tax/shipping rules and Supabase RLS have been tested.
