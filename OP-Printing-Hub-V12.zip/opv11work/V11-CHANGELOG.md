# OP Printing Hub — V11 Changelog

## Privacy & production polish
- Hardened public order tracking: order number + matching customer phone are required.
- Removed the previous order-number-only lookup that could expose order status to anyone guessing an ID.
- Added clear privacy guidance to the tracking UI.
- Improved tracking form error handling and loading state cleanup.
- Updated README for V11.

## Verification
- JavaScript syntax checks should be run with `node --check` across JS files.
- Run `npm install` then `npm run build` in a network-enabled Node environment before deployment.
