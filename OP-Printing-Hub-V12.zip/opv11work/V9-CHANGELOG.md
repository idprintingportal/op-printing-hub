# OP Printing Hub V9

V9 turns the V8 foundation into a more complete operations-ready printing storefront.

### Added
- Admin order detail workspace
- Production + delivery status workflow
- Carrier, tracking number, estimated delivery and customer note fields
- Customer order detail dashboard
- Print-ready invoice page with browser PDF support
- Expanded public order tracking with delivery information
- Admin API with role verification for order updates
- Database indexes for order operations
- Deployment and Razorpay webhook setup guide

### Security notes
- Admin updates are checked server-side against the authenticated user's `profiles.role`.
- Customer order detail is restricted by Supabase RLS to the signed-in customer.
- Payment secrets remain server-side.
