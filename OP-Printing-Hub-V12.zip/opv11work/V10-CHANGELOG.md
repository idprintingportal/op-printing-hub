# OP Printing Hub V10

## Security + production hardening
- Protected `/invoice/[orderId]`: signed-in customers can only view their own invoice; admins can view any invoice.
- Protected `/admin/*` middleware now checks the authenticated user's `profiles.role` and redirects non-admin users.
- Updated Next.js dynamic-route handling to await `params` in server routes and use the React `use()` helper in client dynamic pages.
- Admin order update API now uses the resolved route id consistently.

## Operational notes
- Customer tracking remains public but exposes only order progress, payment state, total, carrier and tracking information—no customer address, phone or email.
- Private artwork storage remains behind Supabase authenticated access.
