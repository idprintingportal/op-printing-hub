create extension if not exists pgcrypto;
create type public.user_role as enum ('customer','admin');
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, full_name text, phone text, role public.user_role not null default 'customer', created_at timestamptz not null default now());
create table if not exists public.products (id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null, category text, description text, base_price numeric(12,2) not null default 0, active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.quotes (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete set null, name text not null, phone text not null, email text, service text, quantity integer, details text, artwork_path text, status text not null default 'new', created_at timestamptz not null default now());
create table if not exists public.orders (id uuid primary key default gen_random_uuid(), order_id text unique not null, user_id uuid references auth.users(id) on delete set null, customer_name text not null, customer_phone text not null, customer_email text, shipping_address jsonb, subtotal numeric(12,2) not null default 0, shipping_fee numeric(12,2) not null default 0, total_amount numeric(12,2) not null default 0, currency text not null default 'INR', status text not null default 'received', payment_status text not null default 'pending', payment_provider text, payment_reference text, payment_id text unique, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.order_items (id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade, product_id uuid references public.products(id) on delete set null, product_name text not null, quantity integer not null, unit_price numeric(12,2) not null, options jsonb not null default '{}', artwork_path text, created_at timestamptz not null default now());
create table if not exists public.order_status_history (id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade, status text not null, note text, changed_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now());
create table if not exists public.artwork_files (id uuid primary key default gen_random_uuid(), order_id uuid references public.orders(id) on delete cascade, user_id uuid references auth.users(id) on delete cascade, file_path text not null, file_name text not null, mime_type text, file_size bigint, created_at timestamptz not null default now());
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users; create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security; alter table public.products enable row level security; alter table public.quotes enable row level security; alter table public.orders enable row level security; alter table public.order_items enable row level security; alter table public.order_status_history enable row level security; alter table public.artwork_files enable row level security;
drop policy if exists products_public_read on public.products; create policy products_public_read on public.products for select using (active=true or public.is_admin());
drop policy if exists profiles_self on public.profiles; create policy profiles_self on public.profiles for select using (id=auth.uid() or public.is_admin());
drop policy if exists orders_owner_read on public.orders; create policy orders_owner_read on public.orders for select using (user_id=auth.uid() or public.is_admin());
drop policy if exists order_items_owner_read on public.order_items; create policy order_items_owner_read on public.order_items for select using (exists(select 1 from public.orders o where o.id=order_id and (o.user_id=auth.uid() or public.is_admin())));
drop policy if exists artwork_owner_read on public.artwork_files; create policy artwork_owner_read on public.artwork_files for select using (user_id=auth.uid() or public.is_admin());
drop policy if exists admin_all_products on public.products; create policy admin_all_products on public.products for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists admin_all_quotes on public.quotes; create policy admin_all_quotes on public.quotes for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists admin_all_orders on public.orders; create policy admin_all_orders on public.orders for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists admin_all_items on public.order_items; create policy admin_all_items on public.order_items for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists admin_all_history on public.order_status_history; create policy admin_all_history on public.order_status_history for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists admin_all_artwork on public.artwork_files; create policy admin_all_artwork on public.artwork_files for all using (public.is_admin()) with check (public.is_admin());
insert into storage.buckets(id,name,public) values('artwork','artwork',false) on conflict(id) do nothing;


-- V7 payment + private artwork hardening (safe to run after the base schema)
alter table public.orders add column if not exists payment_id text unique;
alter table public.orders add column if not exists payment_verified_at timestamptz;

drop policy if exists artwork_owner_insert on public.artwork_files;
create policy artwork_owner_insert on public.artwork_files for insert with check (user_id=auth.uid() and exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));

-- Private Storage policies: authenticated customers can manage only their own order folder.
drop policy if exists artwork_storage_insert on storage.objects;
create policy artwork_storage_insert on storage.objects for insert to authenticated with check (bucket_id='artwork' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists artwork_storage_read on storage.objects;
create policy artwork_storage_read on storage.objects for select to authenticated using (bucket_id='artwork' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists artwork_storage_delete on storage.objects;
create policy artwork_storage_delete on storage.objects for delete to authenticated using (bucket_id='artwork' and (storage.foldername(name))[1] = auth.uid()::text);


-- V8 payment lifecycle + webhook idempotency
create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  event_id text unique not null,
  event_type text not null,
  payload jsonb not null default '{}',
  created_at timestamptz not null default now()
);
alter table public.payment_events enable row level security;
drop policy if exists admin_all_payment_events on public.payment_events;
create policy admin_all_payment_events on public.payment_events for all using (public.is_admin()) with check (public.is_admin());

-- V9 operations, shipping and invoice fields
alter table public.orders add column if not exists carrier text;
alter table public.orders add column if not exists tracking_number text;
alter table public.orders add column if not exists estimated_delivery date;
alter table public.orders add column if not exists customer_note text;
alter table public.orders add column if not exists invoice_number text unique;

create index if not exists orders_status_idx on public.orders(status);
create index if not exists orders_created_at_idx on public.orders(created_at desc);
create index if not exists orders_tracking_idx on public.orders(tracking_number);

-- Backfill human-friendly invoice numbers for existing orders when possible.
update public.orders
set invoice_number = 'OP-INV-' || upper(substr(replace(order_id, 'OP-', ''), 1, 8))
where invoice_number is null;
