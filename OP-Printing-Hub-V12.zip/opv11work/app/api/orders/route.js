import { NextResponse } from 'next/server'
import crypto from 'crypto'
import { supabaseAdmin } from '../../../lib/supabase'
import { calculateLinePrice, calculateOrderTotal } from '../../../lib/pricing'
import { createServerSupabase } from '../../../lib/supabase-server'

export async function POST(req) {
  const supabase = await createServerSupabase()
  const { data: { user } } = await supabase.auth.getUser()
  const body = await req.json()
  const customer = body.customer || {}
  const normalizedPhone = String(customer.phone || '').replace(/\D/g, '').slice(-10)
  if (normalizedPhone.length !== 10) return NextResponse.json({ error: 'Enter a valid 10-digit mobile number.' }, { status: 400 })
  const items = Array.isArray(body.items) ? body.items : []
  if (!customer.name || !customer.phone || !items.length) return NextResponse.json({ error: 'Customer name, phone and at least one item are required.' }, { status: 400 })
  const ids = items.map(x => x.productId).filter(Boolean)
  const { data: products, error } = await supabaseAdmin.from('products').select('id,name,base_price,active').in('id', ids)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  const map = new Map((products || []).map(p => [p.id, p]))
  const normalized = []
  for (const item of items) {
    const p = map.get(item.productId)
    const qty = Math.max(1, Math.min(100000, Number(item.quantity) || 1))
    if (!p || !p.active) return NextResponse.json({ error: 'One or more products are unavailable.' }, { status: 400 })
    const options = item.options || {}
    normalized.push({ productId: p.id, productName: p.name, quantity: qty, unitPrice: calculateLinePrice({ basePrice: Number(p.base_price), quantity: qty, printing: options.printing || 'single', paperType: options.paperType || 'standard', finishType: options.finishType || 'standard', designHelp: Boolean(options.designHelp) }), options, artworkPath: item.artworkPath || null })
  }
  const totals = calculateOrderTotal(normalized.map(x => ({ basePrice: x.unitPrice / x.quantity, quantity: x.quantity, printing: x.options.printing || 'single', paperType: x.options.paperType || 'standard', finishType: x.options.finishType || 'standard', designHelp: Boolean(x.options.designHelp) })))
  const orderId = `OP-${crypto.randomBytes(4).toString('hex').toUpperCase()}`
  const { data: order, error: orderError } = await supabaseAdmin.from('orders').insert({ order_id: orderId, user_id: user?.id || null, customer_name: customer.name, customer_phone: normalizedPhone, customer_email: customer.email || null, shipping_address: customer.address || null, subtotal: totals.subtotal, shipping_fee: totals.shipping, total_amount: totals.total }).select().single()
  if (orderError) return NextResponse.json({ error: orderError.message }, { status: 500 })
  const rows = normalized.map(x => ({ order_id: order.id, product_id: x.productId, product_name: x.productName, quantity: x.quantity, unit_price: x.unitPrice / x.quantity, options: x.options, artwork_path: x.artworkPath }))
  const { error: itemsError } = await supabaseAdmin.from('order_items').insert(rows)
  if (itemsError) return NextResponse.json({ error: itemsError.message }, { status: 500 })
  await supabaseAdmin.from('order_status_history').insert({ order_id: order.id, status: 'received', changed_by: user?.id || null })
  return NextResponse.json({ ok: true, orderId, internalOrderId: order.id, amount: totals.total, status: 'received' })
}
