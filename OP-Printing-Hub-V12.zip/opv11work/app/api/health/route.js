export async function GET() {
  return Response.json({
    ok: true,
    app: "OP Printing Hub",
    version: "V3.1",
    features: ["catalogue", "orders", "quotes", "tracking", "payment-adapter", "admin-foundation"]
  });
}
