import { NextResponse } from 'next/server'
import { supabaseAdmin } from '../../../lib/supabase'

function normalizePhone(value='') { return String(value).replace(/\D/g, '').slice(-10) }

export async function GET(req) {
  const url = new URL(req.url)
  const id = String(url.searchParams.get('orderId') || '').trim()
  const phone = normalizePhone(url.searchParams.get('phone') || '')
  if (!id || phone.length !== 10) return NextResponse.json({ error: 'Order number and 10-digit phone number are required.' }, { status: 400 })

  const { data, error } = await supabaseAdmin
    .from('orders')
    .select('order_id,status,payment_status,total_amount,created_at,updated_at,carrier,tracking_number,estimated_delivery')
    .eq('order_id', id)
    .eq('customer_phone', phone)
    .maybeSingle()

  if (error || !data) return NextResponse.json({ error: 'Order not found. Check the order number and phone number.' }, { status: 404 })
  return NextResponse.json(data)
}
