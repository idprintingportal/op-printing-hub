import { NextResponse } from 'next/server'
import { createServerSupabase } from '../../../../lib/supabase-server'
import { supabaseAdmin } from '../../../../lib/supabase'

export async function GET(req, { params }) {
  const { id } = await params
  const supabase = await createServerSupabase()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 })

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).maybeSingle()
  const isAdmin = profile?.role === 'admin'
  const query = supabaseAdmin.from('artwork_files').select('id,file_path,file_name,mime_type').eq('id', id).single()
  const { data: artwork, error } = await query
  if (error || !artwork) return NextResponse.json({ error: 'Artwork not found.' }, { status: 404 })

  if (!isAdmin) {
    const { data: owned } = await supabaseAdmin.from('artwork_files').select('id').eq('id', id).eq('user_id', user.id).maybeSingle()
    if (!owned) return NextResponse.json({ error: 'Access denied.' }, { status: 403 })
  }

  const bucket = process.env.SUPABASE_ARTWORK_BUCKET || 'artwork'
  const { data: signed, error: signedError } = await supabaseAdmin.storage.from(bucket).createSignedUrl(artwork.file_path, 300)
  if (signedError || !signed?.signedUrl) return NextResponse.json({ error: 'Unable to create secure file link.' }, { status: 500 })
  return NextResponse.json({ ok: true, url: signed.signedUrl, fileName: artwork.file_name, expiresIn: 300 })
}
