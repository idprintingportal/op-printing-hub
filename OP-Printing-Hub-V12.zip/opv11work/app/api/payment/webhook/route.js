import crypto from 'crypto'
import { NextResponse } from 'next/server'
import { supabaseAdmin } from '../../../../lib/supabase'

export async function POST(req) {
  const raw = await req.text()
  const signature = req.headers.get('x-razorpay-signature') || ''
  const eventId = req.headers.get('x-razorpay-event-id') || ''
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET || ''
  if (!secret) return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 503 })
  const expected = crypto.createHmac('sha256', secret).update(raw).digest('hex')
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
  let event
  try { event = JSON.parse(raw) } catch { return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 }) }

  if (eventId) {
    const { error } = await supabaseAdmin.from('payment_events').insert({ event_id: eventId, event_type: event.event || 'unknown', payload: event })
    if (error && error.code === '23505') return NextResponse.json({ ok: true, duplicate: true })
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  }

  const type = event.event || ''
  const payment = event.payload?.payment?.entity
  const refund = event.payload?.refund?.entity
  const orderRef = payment?.order_id
  const paymentId = payment?.id
  let order = null

  if (orderRef) {
    const result = await supabaseAdmin.from('orders').select('id,order_id,total_amount,payment_status,payment_id,payment_reference').eq('payment_reference', orderRef).single()
    order = result.data
  }
  if (!order && paymentId) {
    const result = await supabaseAdmin.from('orders').select('id,order_id,total_amount,payment_status,payment_id,payment_reference').eq('payment_id', paymentId).single()
    order = result.data
  }
  if (!order && refund?.payment_id) {
    const result = await supabaseAdmin.from('orders').select('id,order_id,total_amount,payment_status,payment_id,payment_reference').eq('payment_id', refund.payment_id).single()
    order = result.data
  }
  if (!order) return NextResponse.json({ ok: true, ignored: true })

  const now = new Date().toISOString()
  if (type === 'payment.captured' || type === 'payment.authorized') {
    // Only captured payments are considered paid. Authorized events are recorded but not promoted.
    if (type === 'payment.captured') {
      await supabaseAdmin.from('orders').update({ payment_status: 'paid', payment_provider: 'razorpay', payment_reference: order.payment_reference || orderRef, payment_id: paymentId || order.payment_id, status: 'payment_confirmed', payment_verified_at: now, updated_at: now }).eq('id', order.id)
      await supabaseAdmin.from('order_status_history').insert({ order_id: order.id, status: 'payment_confirmed', note: `Webhook ${type}: ${paymentId || ''}` })
    }
  } else if (type === 'payment.failed') {
    await supabaseAdmin.from('orders').update({ payment_status: 'failed', payment_provider: 'razorpay', payment_reference: order.payment_reference || orderRef, payment_id: paymentId || order.payment_id, updated_at: now }).eq('id', order.id)
    await supabaseAdmin.from('order_status_history').insert({ order_id: order.id, status: 'payment_failed', note: `Webhook payment.failed: ${payment?.error_description || 'Payment failed'}` })
  } else if (type.startsWith('refund.')) {
    await supabaseAdmin.from('orders').update({ payment_status: 'refunded', updated_at: now }).eq('id', order.id)
    await supabaseAdmin.from('order_status_history').insert({ order_id: order.id, status: 'refunded', note: `Webhook ${type}: ${refund?.id || ''}` })
  }
  return NextResponse.json({ ok: true })
}
