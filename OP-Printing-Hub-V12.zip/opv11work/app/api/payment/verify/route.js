import crypto from 'crypto'
import { NextResponse } from 'next/server'
import { supabaseAdmin } from '../../../../lib/supabase'

export async function POST(req) {
  try {
    const { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json()
    if (!orderId || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) return NextResponse.json({ error: 'Payment verification data is incomplete.' }, { status: 400 })
    const { data: order, error } = await supabaseAdmin.from('orders').select('id,order_id,total_amount,currency,payment_status,payment_reference,payment_id').eq('order_id', orderId).single()
    if (error || !order) return NextResponse.json({ error: 'Order not found.' }, { status: 404 })
    if (order.payment_status === 'paid' && order.payment_id === razorpay_payment_id) return NextResponse.json({ ok: true, status: 'paid', orderId })
    if (order.payment_reference !== razorpay_order_id) return NextResponse.json({ error: 'Payment order does not match this order.' }, { status: 400 })
    const key = process.env.RAZORPAY_KEY_ID
    const secret = process.env.RAZORPAY_KEY_SECRET
    if (!key || !secret) return NextResponse.json({ error: 'Payment verification is not configured.' }, { status: 503 })

    const expected = crypto.createHmac('sha256', secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex')
    const a = Buffer.from(expected), b = Buffer.from(String(razorpay_signature))
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return NextResponse.json({ error: 'Invalid payment signature.' }, { status: 400 })

    // Confirm the signed payment against Razorpay itself before marking the order paid.
    const auth = Buffer.from(`${key}:${secret}`).toString('base64')
    const response = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(razorpay_payment_id)}`, { headers: { Authorization: `Basic ${auth}` }, cache: 'no-store' })
    const payment = await response.json()
    if (!response.ok) return NextResponse.json({ error: 'Unable to confirm payment with Razorpay.' }, { status: 502 })
    const expectedPaise = Math.round(Number(order.total_amount) * 100)
    if (payment.order_id !== razorpay_order_id || Number(payment.amount) !== expectedPaise || payment.currency !== (order.currency || 'INR')) return NextResponse.json({ error: 'Payment amount or order does not match.' }, { status: 400 })
    if (payment.status !== 'captured') return NextResponse.json({ error: `Payment is not captured yet (${payment.status || 'unknown'}).` }, { status: 409 })

    const now = new Date().toISOString()
    const { error: updateError } = await supabaseAdmin.from('orders').update({ payment_status: 'paid', payment_provider: 'razorpay', payment_reference: razorpay_order_id, payment_id: razorpay_payment_id, status: 'payment_confirmed', payment_verified_at: now, updated_at: now }).eq('id', order.id).neq('payment_status', 'paid')
    if (updateError) return NextResponse.json({ error: updateError.message }, { status: 500 })
    await supabaseAdmin.from('order_status_history').insert({ order_id: order.id, status: 'payment_confirmed', note: `Razorpay payment ${razorpay_payment_id}` })
    return NextResponse.json({ ok: true, status: 'paid', orderId })
  } catch { return NextResponse.json({ error: 'Invalid request.' }, { status: 400 }) }
}
