import { NextResponse } from 'next/server'
import { createServerSupabase } from '../../../../../lib/supabase-server'
import { supabaseAdmin } from '../../../../../lib/supabase'

const statuses = ['received','payment_confirmed','artwork_review','in_production','ready','shipped','delivered','cancelled']

export async function PATCH(req, { params }) {
  const { id } = await params
  const supabase = await createServerSupabase()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 })
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  const body = await req.json()
  const update = {}
  if (body.status !== undefined) {
    if (!statuses.includes(body.status)) return NextResponse.json({ error: 'Invalid status.' }, { status: 400 })
    update.status = body.status
  }
  for (const key of ['carrier','tracking_number','estimated_delivery','customer_note']) {
    if (body[key] !== undefined) update[key] = body[key] || null
  }
  if (!Object.keys(update).length) return NextResponse.json({ error: 'No changes supplied.' }, { status: 400 })
  update.updated_at = new Date().toISOString()
  const { data: order, error } = await supabaseAdmin.from('orders').update(update).eq('id', id).select('id,order_id,status,carrier,tracking_number,estimated_delivery,customer_note').single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  if (body.status) await supabaseAdmin.from('order_status_history').insert({ order_id: id, status: body.status, note: body.note || null, changed_by: user.id })
  return NextResponse.json({ ok: true, order })
}
