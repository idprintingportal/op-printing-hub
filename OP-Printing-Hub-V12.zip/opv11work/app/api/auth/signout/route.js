import { createServerSupabase } from '../../../../lib/supabase-server'
import { NextResponse } from 'next/server'
export async function POST() { const supabase = await createServerSupabase(); await supabase.auth.signOut(); return NextResponse.json({ ok: true }) }
