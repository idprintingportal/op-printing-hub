import {notFound} from 'next/navigation'
import OrderBuilder from '../../../components/OrderBuilder'
import {supabaseAdmin} from '../../../lib/supabase'
export default async function Product({params}){const {slug}=await params;const {data}=await supabaseAdmin.from('products').select('*').eq('slug',slug).eq('active',true).single();if(!data)return notFound();return <main className="page"><a href="/">← All products</a><div className="product-head"><div><span className="eyebrow">OP PRINTING HUB</span><h1>{data.name}</h1><p>{data.description||'Custom printing with flexible quantity and finish options.'}</p></div><div className="price-card"><span>Starting from</span><strong>₹{Number(data.base_price).toFixed(0)}</strong></div></div><OrderBuilder product={data}/></main>}
