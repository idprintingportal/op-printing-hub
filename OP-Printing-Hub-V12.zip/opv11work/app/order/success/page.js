import Link from 'next/link'

export default async function Success({ searchParams }) {
  const p = await searchParams
  const id = p?.orderId || ''
  const wa = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER
  const text = encodeURIComponent(`Hello OP Printing Hub, my order ${id} has been paid online. Please confirm.`)
  return <main className="page"><div className="panel narrow"><span className="eyebrow">ORDER CONFIRMED</span><h1>Payment successful</h1><p>Your order <b>{id}</b> has been securely marked as paid.</p><p className="muted">Keep this order ID for tracking and support.</p><div className="actions"><Link className="button" href={`/track?orderId=${encodeURIComponent(id)}`}>Track order</Link>{wa && <a className="button secondary" href={`https://wa.me/${wa}?text=${text}`} target="_blank" rel="noreferrer">WhatsApp us</a>}</div></div></main>
}
