import Link from 'next/link'
export default function Order(){return <main className="page"><div className="panel narrow"><span className="eyebrow">ORDER FLOW</span><h1>Your order is almost ready.</h1><p>Choose a product from the catalogue to configure quantity, paper, finish and design assistance.</p><Link className="button" href="/#products">Browse products</Link></div></main>}
