import "./globals.css";

export const metadata = {
  title: "OP Printing Hub | Print • Design • Deliver",
  description: "Online printing, custom products and business printing from OP Printing Hub."
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}