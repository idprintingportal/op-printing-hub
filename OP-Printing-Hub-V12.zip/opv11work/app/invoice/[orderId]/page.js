import { createServerSupabase } from '../../../lib/supabase-server'
import Link from 'next/link'
import PrintButton from '../../../components/PrintButton'
export const dynamic='force-dynamic'

export default async function Invoice({params}){
 const {orderId}=await params
 const supabase=await createServerSupabase()
 const {data:{user}}=await supabase.auth.getUser()
 if(!user)return <main className="page"><div className="panel narrow"><h1>Sign in required</h1><p>Sign in to view your invoice.</p><Link className="button" href={`/login?next=/invoice/${encodeURIComponent(orderId)}`}>Sign in</Link></div></main>
 const {data:profile}=await supabase.from('profiles').select('role').eq('id',user.id).maybeSingle()
 const isAdmin=profile?.role==='admin'
 const query=supabase.from('orders').select('*').eq('order_id',orderId)
 const {data:o}=isAdmin?await query.single():await query.eq('user_id',user.id).single()
 if(!o)return <main className="page"><div className="panel"><h1>Invoice not found</h1><Link className="button" href="/">Go home</Link></div></main>
 const {data:items}=await supabase.from('order_items').select('*').eq('order_id',o.id).order('created_at')
 const a=o.shipping_address
 return <main className="page invoice"><div className="invoice-actions"><Link className="button" href="/">OP Printing Hub</Link><PrintButton/></div><section className="invoice-sheet"><div className="invoice-top"><div><img src="/logo.svg" alt="OP Printing Hub" className="invoice-logo"/><p className="muted">Print • Design • Deliver</p></div><div className="right"><span>INVOICE</span><h2>{o.invoice_number||`OP-INV-${o.order_id.replace('OP-','')}`}</h2><p>Order: <b>{o.order_id}</b><br/>{new Date(o.created_at).toLocaleDateString()}</p></div></div><div className="invoice-grid"><div><b>Billed to</b><p>{o.customer_name}<br/>{o.customer_phone}<br/>{o.customer_email||''}</p></div><div><b>Delivery</b><p>{a?.line1||a||'—'}{a?.city?`, ${a.city}`:''}{a?.pincode?` - ${a.pincode}`:''}</p></div></div><table><thead><tr><th>Description</th><th>Qty</th><th>Unit price</th><th>Total</th></tr></thead><tbody>{(items||[]).map(i=><tr key={i.id}><td><b>{i.product_name}</b><br/><small>{Object.entries(i.options||{}).map(([k,v])=>`${k}: ${String(v)}`).join(' · ')}</small></td><td>{i.quantity}</td><td>₹{Number(i.unit_price).toFixed(2)}</td><td>₹{(Number(i.unit_price)*i.quantity).toFixed(2)}</td></tr>)}</tbody></table><div className="totals"><p>Subtotal <b>₹{Number(o.subtotal).toFixed(2)}</b></p><p>Shipping <b>₹{Number(o.shipping_fee).toFixed(2)}</b></p><h3>Total <b>₹{Number(o.total_amount).toFixed(2)}</b></h3></div><div className="invoice-foot"><p>Payment: <b>{o.payment_status}</b></p><p>Thank you for choosing OP Printing Hub.</p></div></section></main>
}
