'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '../../../lib/supabase-browser'
export default function Login(){
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(false); const router=useRouter()
 async function submit(e){e.preventDefault();setLoading(true);setError('');const {error}=await createClient().auth.signInWithPassword({email,password});if(error)setError(error.message);else router.push('/admin');setLoading(false)}
 return <main className="page"><div className="panel narrow"><h1>Admin Login</h1><p>Secure access for OP Printing Hub staff.</p><form onSubmit={submit} className="form"><input type="email" placeholder="Admin email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button disabled={loading}>{loading?'Signing in…':'Sign in'}</button>{error&&<div className="error">{error}</div>}</form></div></main>
}
