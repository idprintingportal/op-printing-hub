# OP Printing Hub V8 — Changelog

## Payment lifecycle hardening
- Razorpay payment verification now validates the signature, payment/order relationship, amount, currency and captured status against Razorpay's API before marking an order paid.
- Webhook handler now verifies HMAC, stores Razorpay event IDs for idempotency, and reconciles captured, failed and refund events.
- Added `payment_events` table and RLS admin policy.

## Customer ordering
- Product order builder now collects a delivery address.
- Optional artwork upload is sent to the secure private bucket immediately after order creation when the customer is authenticated.
- Checkout follows successful order creation so the customer can pay online.
- Order API returns its internal UUID for secure post-order artwork upload.

## Support
- Payment success page provides tracking and WhatsApp actions.
- Documentation updated for Razorpay test-mode webhook setup and production safety.

## Production gate
Before live launch, test: successful payment, failed payment, duplicate webhook, partial/full refund, abandoned checkout, artwork upload permissions, RLS policies, and order totals/tax/shipping rules.
