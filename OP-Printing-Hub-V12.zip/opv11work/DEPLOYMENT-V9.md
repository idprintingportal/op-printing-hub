# OP Printing Hub V9 deployment

## Stack
- Next.js 15 + React 19
- Supabase: Auth, Postgres, Storage
- Razorpay: order creation, signed verification and webhook lifecycle
- Vercel/Netlify compatible deployment

## 1. Supabase
Run `supabase/schema.sql` in the Supabase SQL editor. Create an admin user through Supabase Auth, then set that user's `profiles.role` to `admin`.

## 2. Environment variables
Copy `.env.example` to `.env.local` and set:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

Keep the service role and Razorpay secret server-side only.

## 3. Razorpay webhook
Set the webhook URL to `/api/payment/webhook` and use the same webhook secret as `RAZORPAY_WEBHOOK_SECRET`. Enable payment captured, payment failed and refund events.

## 4. Build
```bash
npm install
npm run build
npm start
```

## 5. Admin workflow
`/admin` → Orders → open an order. Admin can update production status, carrier, tracking number, estimated delivery and notes. Customer can view the same delivery fields from the account and tracking pages.

## 6. Invoice
`/invoice/OP-XXXXXXXX` provides a print-ready invoice. The browser's Print dialog can save it as PDF without requiring a paid PDF service.
