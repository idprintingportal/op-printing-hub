'use client'
import {useMemo,useState} from 'react'
import {useRouter} from 'next/navigation'
import Link from 'next/link'
import {createClient} from '../lib/supabase-browser'

export default function OrderBuilder({product}){
 const [quantity,setQuantity]=useState(100),[printing,setPrinting]=useState('single'),[paperType,setPaperType]=useState('standard'),[finishType,setFinishType]=useState('standard'),[designHelp,setDesignHelp]=useState(false),[name,setName]=useState(''),[phone,setPhone]=useState(''),[email,setEmail]=useState(''),[address,setAddress]=useState(''),[file,setFile]=useState(null),[busy,setBusy]=useState(false),[message,setMessage]=useState(''); const router=useRouter()
 const estimate=useMemo(()=>{const opt=(printing==='double'?80:0)+(paperType==='premium'?50:paperType==='heavy'?100:0)+(finishType==='standard'?0:finishType==='lamination'?100:50)+(designHelp?100:0);return (Number(product.base_price)+opt)*Math.max(1,Number(quantity)||1)},[product,quantity,printing,paperType,finishType,designHelp])
 async function submit(e){e.preventDefault();setBusy(true);setMessage('');try{if(file){const {data:{user}}=await createClient().auth.getUser();if(!user)throw new Error('Please sign in before uploading artwork. You can place an order without artwork and upload it later.')}const res=await fetch('/api/orders',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({customer:{name,phone,email,address},items:[{productId:product.id,quantity:Number(quantity),options:{printing,paperType,finishType,designHelp}}]})});const data=await res.json();if(!res.ok)throw new Error(data.error||'Unable to create order')
   if(file){const form=new FormData();form.append('file',file);form.append('orderId',data.internalOrderId);const up=await fetch('/api/upload',{method:'POST',body:form});const ud=await up.json();if(!up.ok)throw new Error(ud.error||'Artwork upload failed. Order was created; you can upload artwork after signing in.')}
   router.push('/checkout?orderId='+encodeURIComponent(data.orderId))
 }catch(err){setMessage(err.message)}finally{setBusy(false)}}
 return <form className="builder" onSubmit={submit}><div className="builder-grid"><div>
   <label>Quantity<input type="number" min="1" value={quantity} onChange={e=>setQuantity(e.target.value)}/></label>
   <label>Printing<select value={printing} onChange={e=>setPrinting(e.target.value)}><option value="single">Single side</option><option value="double">Double side</option></select></label>
   <label>Paper<select value={paperType} onChange={e=>setPaperType(e.target.value)}><option value="standard">Standard</option><option value="premium">Premium</option><option value="heavy">Heavy</option></select></label>
   <label>Finish<select value={finishType} onChange={e=>setFinishType(e.target.value)}><option value="standard">Standard</option><option value="matte">Matte</option><option value="gloss">Gloss</option><option value="lamination">Lamination</option></select></label>
   <label className="check"><input type="checkbox" checked={designHelp} onChange={e=>setDesignHelp(e.target.checked)}/> Need design assistance</label>
   <label>Delivery address<textarea rows="3" placeholder="Full delivery address" value={address} onChange={e=>setAddress(e.target.value)}/></label>
   <label>Artwork file <input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={e=>setFile(e.target.files?.[0]||null)}/><small>Optional • PDF/JPG/PNG/WEBP • max 15 MB • requires sign-in</small></label>
   <p className="muted">Need an account? <Link href="/login">Sign in / create account</Link> before uploading artwork.</p>
 </div><div className="summary"><span>Estimated total</span><strong>₹{estimate.toFixed(2)}</strong><small>Final amount is recalculated securely on the server.</small><input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/><input placeholder="Phone" value={phone} onChange={e=>setPhone(e.target.value)} required/><input type="email" placeholder="Email (optional)" value={email} onChange={e=>setEmail(e.target.value)}/><button disabled={busy}>{busy?'Creating order…':'Create order & continue to payment'}</button>{message&&<div className="error">{message}</div>}</div></div></form>
}
