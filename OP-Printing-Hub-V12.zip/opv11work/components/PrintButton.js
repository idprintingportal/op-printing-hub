'use client'
export default function PrintButton(){return <button className="btn orange" onClick={()=>window.print()}>Print / Save PDF</button>}
