# OP Printing Hub V12

## Production reliability + secure artwork access

- Added authenticated `/api/artwork/[id]` endpoint that creates 5-minute signed URLs for private artwork files.
- Admin order detail can open artwork through a temporary signed link instead of exposing storage paths.
- Customer order detail can open only their own artwork through the same protected endpoint.
- Order creation now normalizes Indian mobile numbers to the last 10 digits and rejects invalid phone input.
- Artwork upload now checks customer authentication before creating an order, preventing the previous anonymous-order/upload mismatch.
- Added small UI affordance for secure artwork links.

## Verification

- JavaScript syntax checks: run with `node --check` across project JS files.
- Full dependency installation/build should be run in the deployment environment because package installation may be network/time constrained in the development sandbox.
