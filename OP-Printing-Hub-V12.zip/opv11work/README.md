# OP Printing Hub — V11

Production-oriented Next.js + Supabase foundation for an original online printing marketplace.

## V8 highlights
- Responsive storefront and product catalogue
- Server-side price recalculation
- Customer Supabase Auth and account page
- Admin dashboard, products and order status management
- Private artwork upload for authenticated customers
- Razorpay order creation using the REST API
- Razorpay signature + gateway-side payment verification
- Webhook signature verification and webhook idempotency
- Payment captured / failed / refund lifecycle handling
- Public order tracking and WhatsApp support link

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Create an admin user in Supabase Auth, then set that user's `profiles.role` to `admin`.
4. Copy `.env.example` to `.env.local` and fill the Supabase keys.
5. Create a private Storage bucket named `artwork` (the SQL also attempts this automatically).
6. For payments, add Razorpay **test** keys first:
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`
   - `RAZORPAY_WEBHOOK_SECRET`
7. Configure the Razorpay webhook URL as `https://YOUR-DOMAIN/api/payment/webhook` and enable payment captured, payment failed and refund events.
8. Run `npm install` and `npm run dev`.

## Payment safety
Do not switch to live keys until Razorpay test-mode payment, failed payment, duplicate webhook delivery, refund, and order-status reconciliation have all been tested. The browser never decides whether an order is paid: the server verifies the signature and confirms the payment with Razorpay.

## Artwork
Artwork upload is authenticated and restricted to the customer's own order. Supported files: PDF/JPG/PNG/WEBP, maximum 15 MB.

## Deployment
Deploy on a Vercel/Netlify/Cloudflare-style host and add the same environment variables in its dashboard. A free platform subdomain can be used initially; a custom domain can be added later.

## Security
Never expose `SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_SECRET`, or the webhook secret to browser code.


## V10 security hardening
Invoice pages require authentication and enforce customer ownership unless the viewer is an admin. Admin routes also verify the `profiles.role` server-side in middleware.


## V11 privacy upgrade
- Public order tracking now requires both the OP order number and the 10-digit phone number used on the order.
- Tracking responses expose only operational status, payment state, amount and delivery tracking fields.
- Invoice access remains authenticated and ownership-checked.
