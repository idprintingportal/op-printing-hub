# OP Printing Hub V5

V5 adds the first complete customer-facing product configuration and real database-backed order flow.

## Added
- Dynamic `/products/[slug]` product pages
- Product configurator: quantity, printing, paper, finish and design assistance
- Server-backed order creation using active product prices from Supabase
- Customer name/phone/email capture
- Public order tracking remains database-backed
- Product catalogue cards now open their product pages
- Quote form now persists to the `quotes` table
- Production styling for product/order screens

## Before live launch
- Run the SQL schema in Supabase
- Configure environment variables
- Create admin user and promote profile to `admin`
- Add and test Razorpay order creation + webhook reconciliation
- Add customer artwork upload to the order page
- Add shipping address and delivery rules
- Test RLS with both customer and admin accounts
