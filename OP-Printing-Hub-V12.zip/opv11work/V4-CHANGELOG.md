# OP Printing Hub V4 — Build Notes

V4 moves the project from a UI/architecture prototype toward a real production integration layer.

### Added
- Supabase browser + server auth clients
- Admin route protection middleware
- Supabase Auth admin login/sign-out flow
- Admin dashboard statistics
- Admin order status management
- Admin product price/name/active management
- Customer account order view
- Authenticated artwork upload API with file type and 15 MB size validation
- Expanded Supabase schema: profiles, roles, order status history
- RLS policies for customer/admin access boundaries
- Private artwork storage bucket foundation
- Server-side order creation with authoritative product prices from Supabase
- Order item persistence and status history
- Razorpay webhook HMAC-SHA256 signature verification
- Public tracking endpoint backed by Supabase

### Still requires credentials/testing before live use
- Supabase project URL/keys and schema execution
- Admin user's role set to `admin`
- Razorpay API order creation + checkout UI final wiring
- Razorpay webhook URL configured and tested in test mode
- Storage policies reviewed for the exact deployment
- Production domain, business details, GST/tax rules and shipping rules

No real payment should be accepted until Razorpay test-mode reconciliation is completed.
